//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LogViewer.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_LOG_FILTER_VIEW             103
#define IDR_MAINFRAME                   128
#define IDR_FAST_TRACE_LOG_VIEW_TYPE    129
#define IDD_DIALOG_STUDIO_LIST          130
#define IDR_MENU_DETAIL                 132
#define IDC_LIST_ALL_LOGITEMS           1000
#define IDC_LIST_STUDIOS                1001
#define IDC_EDIT_FILTER_STRING          1002
#define IDC_CHECK_DETAIL                1003
#define IDC_CHECK_INFO                  1004
#define IDC_CHECK_TRACE                 1005
#define IDC_CHECK_WARN                  1006
#define IDC_CHECK_ERROR                 1007
#define IDC_EDIT_FULL_TRACEINFO         1009
#define IDC_COMBO_FILTER                1010
#define IDC_EDIT_START_SEQ_NUMBER       1012
#define IDC_EDIT_END_SEQ_NUMBER         1013
#define ID_THREAD_SELECTALL             32773
#define ID_THREAD_UNSELECTALL           32774
#define ID_TOOLS_HIGHLIGHTSAMETHREAD    32777
#define ID_DETAILS_HIGHLIGHT_SAME_THREAD 32778
#define ID_THREAD_SELECTREVERSE         32781
#define ID_DETAILS_COPY_LINE_TEXT       32784
#define ID_DETAILS_COPY_ITEM_TEXT       32785
#define ID_DETAILS_COPY_FULL_LOG        32786
#define ID_DETAILS_DELETE_SELECT_ITEMS  32787
#define ID_CODE_PAGE_UTF8               32790
#define ID_CODE_PAGE_GB2312             32791
#define ID_CODE_PAGE_JAPANESE           32792
#define ID_CODE_PAGE_KOREAN             32793
#define ID_FILE_RELOAD                  32794
#define ID_INDICATOR_FILE_COUNT         59142
#define ID_INDICATOR_PROCESS_COUNT      59143
#define ID_INDICATOR_THREAD_COUNT       59144
#define ID_INDICATOR_LOGITEM_COUNT      59145
#define ID_INDICATOR_SELECTED_LOGITEM   59146

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32799
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
