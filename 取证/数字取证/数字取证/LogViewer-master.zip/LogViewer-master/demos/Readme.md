# Usage

- Open LogViewer.exe
- Choose Configuration from Menu => ConfigIni => Dsh-SpringBoot.ini
- File-> Open the log that what analyze, example is springdemo.log